function Y = Construct_Y(gnd)
%%
% gnd:  ?      
% num_l:  ? �� ?        ?  
% Y:   ?? ?    
num_l=length(gnd);

nClass = length(unique(gnd));
Y = zeros(nClass,length(gnd));
for i = 1:num_l
    for j = 1:nClass
        if j == gnd(i)
            Y(j,i) = 1;
        end  
    end
end
end