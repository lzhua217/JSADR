function [P,A,Z,S,U] = JSADR(X,W,X_label,maxItr,lambda0,lambda1,lambda2,lambda3,dim)
%function

%input
%     X:        d*n training data. Each column is a sample.
%     W:        n*n  K-nearest neighbor graph
%     X_label:  1*n  Training sample labels
%     maxItr��  number of iterations
%     lambda0�� the ��? in objective function (17)
%     lambda1�� the ��? in objective function (17)
%     lambda2��the ��? in objective function (17)
%     lambda3��the ��? in objective function (17)
%     dim��    data dimensionality


%% Initialization

%% initial
Y = Construct_Y(X_label,length(X_label)); 
% B = Construct_B(Y);
class_num = length(unique(X_label));

F_ini=Y;
epsil = 0.01;

    [d,n]=size(X);
%     [n,m]=size(Z);
%     randn('seed',2);
%     B=sign(randn(L,m));


  [tppp,P1] = pca1(X',dim);

P=P1;
dim1=size(P,2);

[tppp,A] = pca1(tppp,class_num);

A=A';  

%     B=sign(randn(L,n));
    
%     
%     A = eye(L,s);
%     P = zeros(d,s);
%     G = eye(d,d);
%     D = diag(sum(Z,2));
    
%     XZ=X*Z;
%     XDX=X*D*X';

miu = 0.01;
rho =1.01;%1.2;%1.01
max_miu = 1e8;
tol  = 1e-5;
tol2 = 1e-2;

C1 = zeros(d,n);
C2 = zeros(n,n);
C3 = zeros(n,n);
E  = zeros(d,n);
Z=W;
H=W;

G = eye(d,d);

XX=X*X';
Ctg = inv(X'*X+2*eye(size(X,2)));

PXX=inv(X*X'+0.01*eye(d));

% distX = L2_distance_1(X,X);

% [tppp,P1] = pca1(X',s);
% 
% P=P1;
    
%% Start iteration
for ite=1:maxItr
    
    
    W_old = W;
    H_old = H;
    Z_old = Z;
    E_old = E;
    
    
      % obtain A
%     PXZ=P'*XZ;
%ԭ�ȳ���
    PXZ=P'*X;
%     PXZ=P'*X*Z;
%     [U,~,V]=svd(PXZ*Y');
%     A=V*U'; 
%     A=real(A);
    %�޸ĺ����
    
%      DD = diag(sum(Z,1));
%     XDX=X*DD*X';
% %     A=B*(W+W')*X'*P*inv(2*P'*XDX*P+lambda4*eye(s)+0.01*eye(s));
%   A=Y*Z*X'*P*inv(P'*XDX*P+lambda4*eye(dim)+0.01*eye(dim));
    A=Y*X'*P*inv(P'*XX*P+0.01*eye(dim));
%     A=real(A);
%      A=(Y*X'*P)/lambda4;

    

  %update W, Z,H
  [Z,S,U,F,E,C1,C2,C3,miu] = LRR_AGR(X,F_ini,Z_ini,class_num,lambda2,lambda3,1,Ctg);
  
  
  F_ini=F;
  Z_ini=Z;
%   S=(S+S')/2;
  
% 
%     %update W
%     K1=X-E+C1/miu;
%     K2=Z+H-(C2+C3)/miu;
%     W = Ctg*(X'*K1+K2);
%     W = W- diag(diag(W));
    
    
%     % -------- Update Z --------- %
%    
% %     distF = L2_distance_1(F',F');            % ����vij
% %     dist  = distX+lambda1*distF;
% %     dist  = distX;
%     
% %      dist = L2_distance_1(X,P*P'*X);
%      dist = lambda0*L2_distance_1(X,P*P'*X); 
%     Z    = W+(C2-dist)/miu;
%     Z     = Z - diag(diag(Z));
%     for ic = 1:n
%         idx    = 1:n;
%         idx(ic) = [];
%         Z(ic,idx) = EProjSimplex_new(Z(ic,idx));          % 
%     end
% %     Z=(Z+Z')/2;
%     Z=max(Z,Z');
  
    
    
    % obtain P
%     %ԭ�ȳ���
%      D = diag(sum(Z,1));
%     XDX=X*DD*X';
%     P=(alpha*G+XDX)\XZ*B'*A;
%       P=(lambda1*G+X*diag(sum(Z,1))*X')\X*Z'*Y'*A;
%��ȷ��
%        P=(XX+lambda0*X*(diag(sum(Z,1))-2*Z)*X'+lambda1*G+lambda5*eye(d))\X*Y'*A;
%        P=(XX+lambda0*X*(diag(sum(S,1))-2*S)*X'+lambda1*G+lambda5*eye(d))\(X*Y'*A);
       P=(XX+lambda0*X*(diag(sum(S,1))-(S+S'))*X'+lambda1*G+0.01*eye(d))\(X*Y'*A);
%        P=real(P);
%        P=(XX+lambda0*X*(diag(sum(Z,1))-Z)*X'+lambda1*G)\X*Y'*A;
%      

%�޸ĺ��
%   AK=inv(Xdiag(sum(Z,1))*X'+0.01*eye(d));
%     
%    DD1=diag(sum(Z,1));
%     AA=PXX*(lambda0*(X*(DD1-2*Z)*X')+lambda1*G+lambda5*eye(d));
%     BB=A'*A;
%     CC=-PXX*X*Y'*A;
%     
%     P = lyap(AA,BB,CC);
%     P=real(P);

    
    %�޸ĺ����
%     D = diag(sum(W,1));
%     XDX=X*D*X';
%     AK=inv(X*diag(sum(W,1))*X'+0.01*eye(d));
%     
%     AA=-2*AK*(XX+XX');
%     BB=2*A*A';
%     CC=AK*X*(W+W')*B'*A;
%     
%     P = lyap(AA,BB,CC);
    
    
    % obtain A
%     PXZ=P'*XZ;
%     PXZ=P'*X*W;
%     [U,~,V]=svd(PXZ*B');
%     A=V*U'; 
    
     % update G 
    Xi1 = sqrt(sum(P.*P,2)+eps);   
    d1 = 0.5./Xi1;  
    G = diag(d1);
    
    % obtain B 
     %ԭ�ȳ���
%     Q = A*PXZ;
%     B = sign(Q);
    
%    QQ=A*P'*X*inv(lambda0*eye(n)+eye(n)-lambda0*(W+W')+lambda0*DD);
%     B = sign(QQ);

    %�޸ĺ����
%     Q=(1/2)*A*P'*X*(W+W');
%     B=sign(Q);
    
%     % obtain H
%     temp1 = W+C3/miu;
%     temp2 = lambda2/miu;
%     H = max(0,temp1-temp2) + min(0,temp1+temp2);  
    
    
    
%      % ------- Update E ---------- %
%     temp1 = X-X*W+C1/miu;
%     temp2 = lambda3/miu;
%     E = max(0,temp1-temp2) + min(0,temp1+temp2);  
    
    
%     % -------- Update C1 C2 C3 miu -------- %
%     L1 = X-X*Z-E;
%     L2 = Z-W;
%     L3 = Z-H;
%     C1 = C1+miu*L1;
%     C2 = C2+miu*L2;
%     C3 = C3+miu*L3;
%      miu = min(rho*miu,max_miu);
    % updating mu
%     miu = min(rho*miu,max_miu);
    
    LL1 = norm(Z-Z_old,'fro');
    LL2 = norm(W-W_old,'fro');
    LL3 = norm(H-H_old,'fro');
    LL4 = norm(E-E_old,'fro');
    SLSL = max(max(max(LL1,LL2),LL3),LL4)/norm(X,'fro');
%     if miu*SLSL < tol2
%         miu = min(rho*miu,max_miu);
%     end
    
    % obtain objective function value
%     testconvergence(ite)=-trace(2*A*P'*X*Y')+trace(P'*XDX*P)-trace(lambda1*P'*XX*P);
    
    % update G 
%     Xi1 = sqrt(sum(P.*P,2)+eps);   
%     d1 = 0.5./Xi1;  
%     G = diag(d1);
    
end

    %obtain F
%     F=A*P';
    
end



function Y = Construct_Y(gnd,num_l)
%%
% gnd:  ?      
% num_l:  ? �� ?        ?  
% Y:   ?? ?    
nClass = length(unique(gnd));
Y = zeros(nClass,length(gnd));
for i = 1:num_l
    for j = 1:nClass
        if j == gnd(i)
            Y(j,i) = 1;
        end  
    end
end
end